package com.techtalentsouth.WeatherApp;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import com.techtalentsouth.WeatherApp.ZipCode;


public interface ZipCodeRepository extends CrudRepository<ZipCode, String> {
	
	List<ZipCode> findAll(); 
	
	ZipCode deleteById(long id); 
	ZipCode findById(long id);

}
