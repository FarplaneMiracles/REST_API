package com.techtalentsouth.WeatherApp;

import javax.persistence.GeneratedValue;

public class ZipCode {
	
	@GeneratedValue
	public String id;
	
	public int ZipCode;

	public ZipCode(String id, int zipCode) {

		this.id = id;
		this.ZipCode = zipCode;
	}

	public ZipCode() {

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public int getZipCode() {
		return ZipCode;
	}

	public void setZipCode(int zipCode) {
		ZipCode = zipCode;
	}

	@Override
	public String toString() {
		return "ZipCode [id=" + id + ", ZipCode=" + ZipCode + "]";
	}

	
	

}
