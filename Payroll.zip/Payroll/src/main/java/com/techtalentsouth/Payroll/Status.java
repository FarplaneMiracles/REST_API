package com.techtalentsouth.Payroll;

enum Status {

  IN_PROGRESS, //
  COMPLETED, //
  CANCELLED
}