package com.techtalentsouth.TransitApp.Model;
import com.techtalentsouth.TransitApp.Model.Location;

public class Geometry {
    public Location location;
}
