package com.techtalentsouth.TransitApp.Model;

public class Geocoding {
    public Geometry geometry;
}