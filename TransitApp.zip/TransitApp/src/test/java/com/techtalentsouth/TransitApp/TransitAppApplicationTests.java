package com.techtalentsouth.TransitApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransitAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
